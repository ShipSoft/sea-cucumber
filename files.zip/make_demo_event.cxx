// SPDX-License-Identifier: LGPL-3.0-or-later
// Copyright (C) CERN for the benefit of the SHiP Collaboration
// =============================================================================
//  make_demo_event -- generate a demonstration event in the official SHiP data
//  model, for showing off sea_cucumber without a full simulation.
//
//  Physics cartoon (NOT a real simulation): a neutral long-lived particle
//  produced at the target travels downstream and decays inside the decay
//  volume into two oppositely-charged daughters (mu+ mu-). The daughters
//  diverge, cross the tracker stations and timing detector, and shower in the
//  calorimeter; a few Surrounding Background Tagger (SBT) cells near the decay
//  also register. The event is written with MC truth (MCParticle), simulation
//  (SimHit + SimParticle, bundled in SimResult) and a reconstructed overlay
//  (RecParticle), so every sea_cucumber drawing path is exercised.
//
//  GEOMETRY-AWARE: given --geometry <ship.db>, the generator walks the real
//  geometry (reusing GeoModelLoader) to find where each subsystem actually is,
//  so the hits land on the detectors you will load. If no geometry is given
//  (or a subsystem isn't found), it falls back to an approximate SHiP layout so
//  it always produces something.
//
//  Units are the data-model native ones: mm, GeV/c, GeV, ns.
//
//  Usage:
//    make_demo_event --geometry ship_geometry.db --output demo_events.root
//                    [--events N] [--seed S]
// =============================================================================

#include <ROOT/RNTupleModel.hxx>
#include <ROOT/RNTupleWriter.hxx>

#include <TGeoMatrix.h>
#include <TGeoShape.h>

#include <algorithm>
#include <array>
#include <cmath>
#include <cstdint>
#include <cstdlib>
#include <iostream>
#include <map>
#include <random>
#include <string>
#include <vector>

#include "GeoModelLoader.h"
#include "SHiP/MCParticle.hpp"
#include "SHiP/RecParticle.hpp"
#include "SHiP/SimHit.hpp"
#include "SHiP/SimParticle.hpp"
#include "SHiP/SimResult.hpp"

namespace {

using Vec3 = std::array<double, 3>;

// ---- subsystem classification from a volume name ---------------------------
enum class Sub { Target, Muon, Tagger, Decay, SBT, Tracker, Magnet, Timing, ECAL, HCAL, Other };

Sub classify(const std::string& n) {
    auto has = [&](const char* s) { return n.find(s) != std::string::npos; };
    if (has("Straw") || has("Tracker")) return Sub::Tracker;
    if (has("ECAL") || has("Ecal")) return Sub::ECAL;
    if (has("HCAL") || has("Hcal")) return Sub::HCAL;
    if (has("Calo")) return Sub::ECAL;
    if (has("SBT") || (has("Tagger") && has("Background"))) return Sub::SBT;
    if (has("Timing")) return Sub::Timing;
    if (has("UpstreamTagger") || has("UBT")) return Sub::Tagger;
    if (has("DecayVolume") || has("Vessel") || has("Decay")) return Sub::Decay;
    if (has("Magnet")) return Sub::Magnet;
    if (has("MuonShield") || has("Muon")) return Sub::Muon;
    if (has("Target")) return Sub::Target;
    return Sub::Other;
}

// Collected geometry: per-subsystem list of volume-centre positions (mm).
struct GeoInfo {
    std::map<Sub, std::vector<Vec3>> centres;

    bool has(Sub s) const {
        auto it = centres.find(s);
        return it != centres.end() && !it->second.empty();
    }
    // Mean z of a subsystem's volumes, or `fallback` if absent.
    double meanZ(Sub s, double fallback) const {
        if (!has(s)) return fallback;
        double sum = 0;
        for (const auto& c : centres.at(s)) sum += c[2];
        return sum / centres.at(s).size();
    }
    std::pair<double, double> zRange(Sub s, double lo, double hi) const {
        if (!has(s)) return {lo, hi};
        double a = 1e30, b = -1e30;
        for (const auto& c : centres.at(s)) {
            a = std::min(a, c[2]);
            b = std::max(b, c[2]);
        }
        return {a, b};
    }
};

GeoInfo loadGeometry(const std::string& db) {
    GeoInfo g;
    if (db.empty()) return g;
    shipdisp::GeoLoadOptions opt;
    opt.include = {};             // match all
    opt.stop_at_match = false;    // descend so we see individual detector volumes
    opt.max_depth = 6;            // but not all the way into 9600 straws
    opt.length_scale = 1.0;       // native mm
    opt.verbose = false;
    try {
        shipdisp::LoadGeoModelDB(
            db, opt,
            [&](const std::string& name, TGeoShape* shape, const TGeoHMatrix& m, int) {
                const Double_t* t = m.GetTranslation();
                g.centres[classify(name)].push_back({t[0], t[1], t[2]});
                delete shape;  // callback owns it; we only need the position
            });
    } catch (const std::exception& e) {
        std::cerr << "[make_demo_event] geometry walk failed (" << e.what()
                  << ") -- using fallback layout\n";
        g.centres.clear();
    }
    return g;
}

// ---- simple vector helpers --------------------------------------------------
Vec3 add(const Vec3& a, const Vec3& b) { return {a[0] + b[0], a[1] + b[1], a[2] + b[2]}; }
Vec3 scale(const Vec3& a, double s) { return {a[0] * s, a[1] * s, a[2] * s}; }
double norm(const Vec3& a) { return std::sqrt(a[0] * a[0] + a[1] * a[1] + a[2] * a[2]); }

// Position of a straight track (vertex v, direction d) at plane z.
Vec3 atZ(const Vec3& v, const Vec3& d, double z) {
    const double s = (z - v[2]) / d[2];
    return {v[0] + d[0] * s, v[1] + d[1] * s, z};
}

}  // namespace

int main(int argc, char* argv[]) {
    std::string geometry, output = "demo_events.root";
    int nEvents = 1;
    unsigned seed = 12345;
    for (int i = 1; i < argc; ++i) {
        std::string a = argv[i];
        auto nxt = [&]() { return (i + 1 < argc) ? argv[++i] : ""; };
        if (a == "--geometry") geometry = nxt();
        else if (a == "--output") output = nxt();
        else if (a == "--events") nEvents = std::atoi(nxt());
        else if (a == "--seed") seed = std::atoi(nxt());
        else if (a == "-h" || a == "--help") {
            std::cout << "Usage: make_demo_event [--geometry ship.db] "
                         "[--output demo_events.root] [--events N] [--seed S]\n";
            return 0;
        }
    }

    const GeoInfo geo = loadGeometry(geometry);
    std::mt19937 rng(seed);
    auto uni = [&](double a, double b) { return std::uniform_real_distribution<>(a, b)(rng); };
    auto gaus = [&](double m, double s) { return std::normal_distribution<>(m, s)(rng); };

    // Subsystem z-anchors: real if found, else an approximate SHiP layout (mm).
    const auto [decLo, decHi] = geo.zRange(Sub::Decay, 30000, 60000);
    const auto [trkLo, trkHi] = geo.zRange(Sub::Tracker, 63000, 70000);
    const double zTarget = geo.meanZ(Sub::Target, 0.0);
    const double zTiming = geo.meanZ(Sub::Timing, trkHi + 2000);
    const double zEcal = geo.meanZ(Sub::ECAL, zTiming + 2000);
    const double zHcal = geo.meanZ(Sub::HCAL, zEcal + 2000);

    // Tracker planes: real straw-station z's if we found them, else 4 synthetic.
    std::vector<double> trackerZ;
    if (geo.has(Sub::Tracker)) {
        for (const auto& c : geo.centres.at(Sub::Tracker)) trackerZ.push_back(c[2]);
        std::sort(trackerZ.begin(), trackerZ.end());
        trackerZ.erase(std::unique(trackerZ.begin(), trackerZ.end(),
                                   [](double x, double y) { return std::abs(x - y) < 50; }),
                       trackerZ.end());
    }
    if (trackerZ.size() < 4)
        for (int k = 0; k < 4; ++k) trackerZ.push_back(trkLo + (trkHi - trkLo) * k / 3.0);

    auto model = ROOT::RNTupleModel::Create();
    auto mcP = model->MakeField<std::vector<SHiP::MCParticle>>("mcParticles");
    auto simH = model->MakeField<std::vector<SHiP::SimHit>>("simHits");
    auto simP = model->MakeField<std::vector<SHiP::SimParticle>>("simParticles");
    auto recP = model->MakeField<std::vector<SHiP::RecParticle>>("recParticles");
    auto simR = model->MakeField<SHiP::SimResult>("simResult");
    auto writer = ROOT::RNTupleWriter::Recreate(std::move(model), "events", output);

    for (int ev = 0; ev < nEvents; ++ev) {
        mcP->clear(); simH->clear(); simP->clear(); recP->clear();
        simR->hits.clear(); simR->particles.clear();

        // --- decay vertex inside the decay volume ----------------------------
        const Vec3 vtx = {gaus(0, 120), gaus(0, 120), uni(decLo + 0.5 * (decHi - decLo), decHi - 2000)};

        // --- mother: neutral, from target, momentum along +z -----------------
        const double Pm = uni(30, 80);  // GeV/c
        const Vec3 pMother = {uni(-0.2, 0.2), uni(-0.2, 0.2), Pm};
        {
            SHiP::MCParticle m;
            m.pdgCode = 9900015;  // HNL-like placeholder
            m.vertex = {0, 0, zTarget};
            m.momentum = pMother;
            m.energy = std::sqrt(Pm * Pm + 1.0);
            m.motherId = -1;
            m.status = 2;  // decayed
            mcP->push_back(m);
        }

        // --- two daughters: split the mother momentum with an opening angle --
        const double theta = uni(0.03, 0.08);  // rad, exaggerated for visibility
        const double phi = uni(0, 2 * M_PI);
        const Vec3 kick = {std::cos(phi) * theta * Pm, std::sin(phi) * theta * Pm, 0};
        std::array<Vec3, 2> pDau = {add(scale(pMother, 0.5), kick),
                                    add(scale(pMother, 0.5), scale(kick, -1))};
        const std::array<int, 2> dauPdg = {13, -13};  // mu-, mu+

        for (int d = 0; d < 2; ++d) {
            const Vec3& p = pDau[d];
            const double P = norm(p);
            const Vec3 dir = scale(p, 1.0 / p[2]);  // normalise so dir.z scales z-steps

            // MC + Sim truth for the daughter.
            SHiP::MCParticle mc;
            mc.pdgCode = dauPdg[d];
            mc.vertex = vtx;
            mc.momentum = p;
            mc.energy = std::sqrt(P * P + 0.105 * 0.105);
            mc.motherId = 0;
            mc.status = 1;
            mcP->push_back(mc);

            const Vec3 endp = atZ(vtx, dir, zHcal + 1000);
            SHiP::SimParticle sp;
            sp.trackId = d + 1;
            sp.parentId = 0;
            sp.pdgCode = dauPdg[d];
            sp.vertex = vtx;
            sp.endpoint = endp;
            sp.momentum = p;
            sp.energy = mc.energy;
            simP->push_back(sp);

            auto pushHit = [&](const Vec3& x, std::int32_t detId, double edep) {
                SHiP::SimHit h;
                h.detectorId = detId;
                h.trackId = d + 1;
                h.pdgCode = dauPdg[d];
                h.position = x;
                h.momentum = p;
                h.energyDeposit = edep;
                h.time = norm(add(x, scale(vtx, -1))) / 299.792458;  // ns, ~c
                h.pathLength = 10;
                simH->push_back(h);
            };

            // Tracker stations.
            int plane = 0;
            for (double z : trackerZ)
                if (z > vtx[2]) pushHit(atZ(vtx, dir, z), 1000 + 100 * d + plane++, uni(0.001, 0.004));
            // Timing detector.
            if (zTiming > vtx[2]) pushHit(atZ(vtx, dir, zTiming), 2000 + d, uni(0.002, 0.005));
            // ECAL shower: a cluster of hits around the track's ECAL crossing.
            const Vec3 e0 = atZ(vtx, dir, zEcal);
            for (int s = 0; s < 25; ++s)
                pushHit({e0[0] + gaus(0, 120), e0[1] + gaus(0, 120), zEcal + gaus(0, 120)},
                        3000 + 100 * d + s, std::abs(gaus(0.15, 0.12)) + 0.01);
            // HCAL: a few deeper deposits.
            const Vec3 h0 = atZ(vtx, dir, zHcal);
            for (int s = 0; s < 8; ++s)
                pushHit({h0[0] + gaus(0, 200), h0[1] + gaus(0, 200), zHcal + gaus(0, 200)},
                        4000 + 100 * d + s, std::abs(gaus(0.3, 0.2)) + 0.02);

            // Reconstructed overlay: smeared daughter.
            SHiP::RecParticle rp;
            rp.trackId = d + 1;
            rp.pdgCode = dauPdg[d];
            rp.vertex = {vtx[0] + gaus(0, 5), vtx[1] + gaus(0, 5), vtx[2] + gaus(0, 20)};
            rp.endpoint = endp;
            rp.momentum = {p[0] * (1 + gaus(0, 0.02)), p[1] * (1 + gaus(0, 0.02)),
                           p[2] * (1 + gaus(0, 0.02))};
            rp.energy = mc.energy * (1 + gaus(0, 0.03));
            rp.ipPV = std::abs(gaus(0, 3));
            recP->push_back(rp);
        }

        // --- SBT: a handful of veto cells near the decay, if geometry has them
        if (geo.has(Sub::SBT)) {
            const auto& cells = geo.centres.at(Sub::SBT);
            for (int s = 0; s < 6 && s < (int)cells.size(); ++s) {
                const auto& c = cells[(s * 7 + ev) % cells.size()];
                SHiP::SimHit h;
                h.detectorId = 5000 + s;
                h.pdgCode = 22;
                h.position = c;
                h.energyDeposit = uni(0.005, 0.05);
                h.time = (c[2] - vtx[2]) / 299.792458;
                simH->push_back(h);
            }
        }

        // Bundle the flat collections into SimResult too.
        simR->hits = *simH;
        simR->particles = *simP;

        writer->Fill();
        std::cout << "[make_demo_event] event " << ev << ": " << simH->size() << " hits, "
                  << mcP->size() << " mc, " << simP->size() << " sim, " << recP->size() << " rec\n";
    }

    std::cout << "[make_demo_event] wrote '" << output << "' (" << nEvents << " event(s))\n";
    return 0;
}
